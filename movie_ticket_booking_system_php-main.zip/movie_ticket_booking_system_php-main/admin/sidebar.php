<div class="admin-section admin-section1" style=" background-color:#262626;">
    <ul>
        <li style=" background-color:#262626;"><i class="fas fa-sliders-h"  style="color:lightblue"></i><a  style="color:lightblue" href="admin.php">Dashboard </a><i class="fas admin-dropdown fa-chevron-right"></i></li>
        <li style=" background-color:#262626;"><i class="fas fa-ticket-alt"  style="color:lightblue"></i><a  style="color:lightblue" href="view.php">Bookings</a> <i class="fas admin-dropdown fa-chevron-right"></i></li>
        <li style=" background-color:#262626;"><i class="fas fa-film"  style="color:lightblue"></i><a  style="color:lightblue" href="addmovie.php">Movies</a> <i class="fas admin-dropdown fa-chevron-right"></i></a></li>
        <!-- <li style=" background-color:#262626;"><i class="fas fa-plus-circle"  style="color:lightblue"></i><a  style="color:lightblue" href="add.php">Add entry</a> <i class="fas admin-dropdown fa-chevron-right"></i></a></li> -->
        <!-- <li><i class="fas fa-id-card"></i><a href="contactus.php">User Feedback</a> <i class="fas admin-dropdown fa-chevron-right"></i></a></li> -->
        <!-- <li><i class="fa fa-check-circle"></i><a href="../TxnStatus.php" target="_blank">Check Status</a> <i class="fas admin-dropdown fa-chevron-right"></i></a></li> -->
    </ul>
</div>
