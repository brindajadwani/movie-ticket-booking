<div class="footer-section footer-section1">
<div class="footer-brand">
    <a href="index.php">
        <h1 class="footer-heading">ARVR Cinema</h1>
    </a> 
</div>    
</div>
<div class="footer-section footer-section2">
    <h2><i class="fas fa-user-alt"></i> Social Media</h2>
    <div class="footer-section-inner-container">
        <span><i class="fab fa-lg fa-facebook-square"></i> Facebook</span>
        <span><i class="fab fa-lg fa-twitter-square"></i> Twitter</span>
        <span><i class="fab fa-lg fa-instagram"></i> Instagram</span>
    </div>
</div>
<div class="footer-section  footer-section3">
    <p>© 2020 ARVR Movies. Created by Query Coder's. </p>
    <a>Advertising</a>
    <a>Privacy Policy</a>
    <a href="contact-us.php">Contact</a>
</div>

<!-- <footer class="bg-dark d-flex justify-content-center">
    <h2 class="text-white" href="#">COVID-19 LIVE STATS</h2>
    <h2 style="color:#fff;">Developed By <a target="_blank" class="navbar-brand line text-white" href="https://github.com/aman05382/">Aman Sharma</a></h2>
</footer> -->